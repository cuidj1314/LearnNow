//>>built
define("dijit/_editor/nls/bg/LinkDialog",({createLinkTitle:"Свойства на връзка",insertImageTitle:"Свойства на изображение",url:"URL:",text:"Описание:",target:"Цел:",set:"Задай",currentWindow:"Текущ прозорец",parentWindow:"Родителски прозорец",topWindow:"Най-горен прозорец",newWindow:"Нов прозорец"}));
