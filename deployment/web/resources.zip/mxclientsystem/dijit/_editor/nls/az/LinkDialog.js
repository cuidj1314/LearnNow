//>>built
define("dijit/_editor/nls/az/LinkDialog",({"text":"Yazı:","insertImageTitle":"Şəkil başlığı əlavə et","set":"Yönəlt","newWindow":"Yeni pəncərə","topWindow":"Üst pəncərə","target":"Hədəf:","createLinkTitle":"Köprü başlığı yarat","parentWindow":"Ana pəncərə","currentWindow":"Hazırki pəncərə","url":"URL:"}));
