//>>built
define("dijit/form/nls/el/ComboBox",({previousMessage:"Προηγούμενες επιλογές",nextMessage:"Περισσότερες επιλογές"}));
